#pip install -U openai-whisper
whisper "audio.mp3" --language English --fp16 False